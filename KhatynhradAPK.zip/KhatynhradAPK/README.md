# 🏘 Хатинград — Android APK

## Що це?
Android додаток з грою Хатинград через WebView.
Гра запускається локально з пристрою — не потрібен інтернет!

---

## 🛠 Що потрібно встановити (безкоштовно)

1. **Android Studio** → https://developer.android.com/studio
   - Розмір: ~1 ГБ
   - Встановлюй з усіма стандартними компонентами

2. **JDK 11+** — зазвичай іде разом з Android Studio

---

## 📂 Структура проєкту

```
KhatynhradAPK/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   ├── index.html     ← ВСЯ ГРА ТУТ
│   │   │   ├── manifest.json
│   │   │   └── sw.js
│   │   ├── java/com/khatynhrad/
│   │   │   └── MainActivity.java
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/styles.xml
│   │   │   └── mipmap-*/ic_launcher.png
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── local.properties  ← ВКАЖИ ШЛЯХ ДО SDK
```

---

## 🚀 Кроки для збірки APK

### Крок 1 — Відкрий проєкт
1. Запусти Android Studio
2. `File → Open` → вибери папку `KhatynhradAPK`
3. Зачекай поки Gradle синхронізується (1-2 хв)

### Крок 2 — Вкажи SDK шлях
Відкрий `local.properties` і встав свій шлях:
```
# Windows:
sdk.dir=C\:\\Users\\ТВОЄ_ІМ'Я\\AppData\\Local\\Android\\Sdk

# Mac:
sdk.dir=/Users/ТВОЄ_ІМ'Я/Library/Android/sdk

# Linux:
sdk.dir=/home/ТВОЄ_ІМ'Я/Android/Sdk
```

### Крок 3 — Збери APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Або через термінал:
```bash
./gradlew assembleDebug
```

### Крок 4 — Знайди APK
```
app/build/outputs/apk/debug/Khatynhrad-v1.0-debug.apk
```

### Крок 5 — Встанови на телефон
1. Надішли APK собі через Telegram / Google Drive
2. Відкрий на телефоні
3. Android запитає: "Дозволити встановлення з невідомих джерел" → **Дозволити**
4. Встановлюється! Іконка 🏘 з'явиться на головному екрані

---

## 🔄 Як оновити гру

1. Відредагуй `app/src/main/assets/index.html`
2. Збери новий APK: `Build → Build APK(s)`
3. Встанови поверх старого (прогрес збережеться!)

Або якщо гра на GitHub Pages — просто зміни URL в MainActivity.java:
```java
// Замість локальної:
webView.loadUrl("file:///android_asset/index.html");

// На онлайн версію:
webView.loadUrl("https://username.github.io/khatynhrad/");
```

---

## ✍️ Підписати APK для поширення

Для debug версії — підпис автоматичний.
Для release (Play Store або поширення):
```
Build → Generate Signed Bundle / APK → APK → Create new keystore
```
Збережи keystore файл у безпечному місці!

---

## 📱 Вимоги до пристрою
- Android 5.0+ (API 21)
- ~10 МБ вільного місця
- Підтримка WebView (є на всіх сучасних Android)

---

## 🆘 Проблеми?

**"SDK not found"** → Відкрий local.properties і вкажи правильний шлях

**"Gradle sync failed"** → File → Invalidate Caches → Restart

**"App not installed"** → Увімкни "Невідомі джерела" в налаштуваннях

**Гра не відображається** → Перевір що index.html є в папці assets/
